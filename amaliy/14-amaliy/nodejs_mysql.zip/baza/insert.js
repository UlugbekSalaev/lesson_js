const mysql = require('mysql');

const con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'davlat',
});

con.connect(function(err){
	if (err) throw err;
	var sql = "insert into davlat (nomi,iso,iso3,phonecode) values('Uzbekiston', 'UZ', 'UZB', 998)";
	con.query(sql, function (err, result){
		if (err) throw err;
		console.log("1 ta satr qushildi:" + JSON.stringify(result));
	});
});


/*
con.connect();
con.query(sql, function(error, results){
	console.log(result);
	con.end();
});
*/