const mysql = require('mysql');

const con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'davlat',
});

con.connect(function(err){
	if (err) throw err;
	con.query("SELECT * FROM davlat", function (err, result, fields){
		if (err) throw err;
		console.log(result[15]["nomi"]);
		
		//for (var key in result) {
		//	console.log(result[key]["nomi"]);
		//}
		//console.log(result);
		//console.log(fields);
	});
});


/*
con.connect();
con.query('SELECT * FROM davlat', function(error, results, fields){
	console.log(JSON.stringify(results));
	con.end();
});
*/