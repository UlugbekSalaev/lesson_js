const mysql = require('mysql');

const con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'davlat',
});

con.connect(function(err){
	if (err) throw err;
	var sql = "delete from davlat where id=";
	con.query(sql, function (err, result){
		if (err) throw err;
		console.log("1 ta satr o`chirildi:" + JSON.stringify(result));
	});
});


/*
con.connect();
con.query(sql, function(error, results){
	console.log(result);
	con.end();
});
*/